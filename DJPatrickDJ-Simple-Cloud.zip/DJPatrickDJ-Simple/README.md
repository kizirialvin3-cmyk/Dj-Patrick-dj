# DJ Patrick DJ — Simple Cloud-Build Edition

This edition is intentionally minimal to make remote/cloud Android builds more reliable.

## Included
- Native Android Java only
- No Kotlin
- No Jetpack Compose
- No AndroidX dependencies
- No Media3/ExoPlayer dependency
- Two audio decks using Android MediaPlayer
- Audio file picker
- Play/pause and cue
- Pitch control
- Crossfader and master volume
- Stem control UI: vocals, drums, bass, other
- FX control UI
- Basic DJ controls and DJ Patrick branding

## Important
The stem and FX sliders are UI controls in this lightweight build; they do not yet perform real stem separation or DSP. Those features should be added after the basic APK builds successfully.

## Cloud build
Use a cloud Android builder that accepts a standard Gradle Android project. Build the `app` module and choose a debug APK first. The expected output is usually under `app/build/outputs/apk/debug/`.
