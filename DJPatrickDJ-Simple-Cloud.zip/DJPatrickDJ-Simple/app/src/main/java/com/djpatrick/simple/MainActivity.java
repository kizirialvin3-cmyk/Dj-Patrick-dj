package com.djpatrick.simple;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    static final int PICK_A = 10, PICK_B = 11;
    MediaPlayer playerA, playerB;
    TextView trackA, trackB, status;
    SeekBar cross, master, pitchA, pitchB;
    float masterValue = .85f, crossValue = .5f;

    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    TextView text(String s, int size) { TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); t.setPadding(dp(8),dp(6),dp(8),dp(6)); return t; }
    LinearLayout row() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    Button btn(String s) { Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); return b; }

    @Override public void onCreate(Bundle b) { super.onCreate(b); build(); }

    void build() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(8),dp(8),dp(8),dp(8)); root.setBackgroundColor(Color.rgb(8,9,11));
        LinearLayout head=row(); TextView title=text("DJ PATRICK  •  PRO DJ MIXER",20); title.setTypeface(null,1); head.addView(title,new LinearLayout.LayoutParams(0,dp(55),1));
        Button rec=btn("● REC"); head.addView(rec,new LinearLayout.LayoutParams(dp(95),dp(55))); root.addView(head);
        ScrollView scroll=new ScrollView(this); LinearLayout content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        LinearLayout decks=row(); decks.addView(deck(0),new LinearLayout.LayoutParams(0,-2,1)); decks.addView(deck(1),new LinearLayout.LayoutParams(0,-2,1)); content.addView(decks);
        content.addView(label("CROSSFADER")); cross=new SeekBar(this); cross.setMax(100); cross.setProgress(50); content.addView(cross); content.addView(label("A                         CENTER                         B"));
        content.addView(label("MASTER VOLUME")); master=new SeekBar(this); master.setMax(100); master.setProgress(85); content.addView(master);
        content.addView(panelTitle("STEMS")); String[] stems={"VOCALS","DRUMS","BASS","OTHER"}; for(String s:stems) addSlider(content,s,100);
        content.addView(panelTitle("EFFECTS")); String[] fx={"FILTER","ECHO","REVERB","FLANGER"}; for(String s:fx) addSlider(content,s,0);
        content.addView(panelTitle("TOOLS")); LinearLayout tools=row(); for(String s:new String[]{"SYNC","LOOP 4","CUE A","CUE B"}) tools.addView(btn(s),new LinearLayout.LayoutParams(0,dp(50),1)); content.addView(tools);
        status=text("Ready • Load a song into either deck",13); status.setTextColor(Color.LTGRAY); content.addView(status);
        scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=row(); for(String s:new String[]{"MIX","LIBRARY","STEMS","FX","SETTINGS"}) nav.addView(btn(s),new LinearLayout.LayoutParams(0,dp(55),1)); root.addView(nav);
        setContentView(root);
        cross.setOnSeekBarChangeListener(new SimpleSeek(){public void onProgressChanged(SeekBar s,int p,boolean f){crossValue=p/100f; updateVolumes();}});
        master.setOnSeekBarChangeListener(new SimpleSeek(){public void onProgressChanged(SeekBar s,int p,boolean f){masterValue=p/100f; updateVolumes();}});
    }

    TextView label(String s){ TextView t=text(s,11); t.setTextColor(Color.GRAY); return t; }
    TextView panelTitle(String s){ TextView t=text("— "+s+" —",15); t.setTypeface(null,1); t.setTextColor(Color.rgb(52,211,153)); return t; }
    void addSlider(LinearLayout c,String name,int value){ c.addView(label(name)); SeekBar s=new SeekBar(this); s.setMax(100); s.setProgress(value); c.addView(s); }

    View deck(final int d){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(5),dp(5),dp(5),dp(5)); box.setBackgroundColor(Color.rgb(20,22,26));
        TextView head=text("DECK "+(d==0?"A":"B"),16); head.setTypeface(null,1); box.addView(head);
        TextView track=text("No track loaded",12); box.addView(track); if(d==0) trackA=track; else trackB=track;
        TextView wave=text("      W A V E F O R M      ",12); wave.setGravity(Gravity.CENTER); wave.setBackgroundColor(Color.rgb(12,14,18)); box.addView(wave,new LinearLayout.LayoutParams(-1,dp(65)));
        Button load=btn("LOAD"); box.addView(load); load.setOnClickListener(v->pick(d));
        Button play=btn("PLAY / PAUSE"); box.addView(play); play.setOnClickListener(v->toggle(d));
        Button cue=btn("CUE"); box.addView(cue); cue.setOnClickListener(v->cue(d));
        box.addView(label("PITCH")); SeekBar pitch=new SeekBar(this); pitch.setMax(32); pitch.setProgress(16); box.addView(pitch); pitch.setOnSeekBarChangeListener(new SimpleSeek(){public void onProgressChanged(SeekBar s,int p,boolean f){setRate(d,1f+(p-16)/100f);}});
        Button loop=btn("LOOP 4 BEATS"); box.addView(loop); return box;
    }
    void pick(int d){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("audio/*"); startActivityForResult(i,d==0?PICK_A:PICK_B); }
    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data); if(c!=RESULT_OK||data==null)return; Uri u=data.getData(); try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION); }catch(Exception ignored){} load(u,r==PICK_A?0:1);}
    void load(Uri u,int d){ try{ MediaPlayer old=d==0?playerA:playerB; if(old!=null)old.release(); MediaPlayer p=new MediaPlayer(); p.setDataSource(this,u); p.prepare(); if(d==0){playerA=p;trackA.setText(name(u));}else{playerB=p;trackB.setText(name(u));} status.setText("Loaded on Deck "+(d==0?"A":"B")); updateVolumes(); }catch(Exception e){status.setText("Could not load audio");} }
    String name(Uri u){String x=u.getLastPathSegment(); return x==null?"Selected track":x;}
    void toggle(int d){MediaPlayer p=d==0?playerA:playerB;if(p==null){status.setText("Load a track first");return;}if(p.isPlaying())p.pause();else p.start();}
    void cue(int d){MediaPlayer p=d==0?playerA:playerB;if(p!=null)p.seekTo(0);}
    void setRate(int d,float r){MediaPlayer p=d==0?playerA:playerB;if(p!=null&&android.os.Build.VERSION.SDK_INT>=23){p.setPlaybackParams(p.getPlaybackParams().setSpeed(Math.max(.5f,Math.min(1.5f,r))));}}
    void updateVolumes(){if(playerA!=null)playerA.setVolume(masterValue*(1-crossValue),masterValue*(1-crossValue));if(playerB!=null)playerB.setVolume(masterValue*crossValue,masterValue*crossValue);}
    abstract class SimpleSeek implements SeekBar.OnSeekBarChangeListener{public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}}
    @Override protected void onDestroy(){if(playerA!=null)playerA.release();if(playerB!=null)playerB.release();super.onDestroy();}
}
